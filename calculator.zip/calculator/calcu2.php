<?php

if(isset($_POST['equal']))
{
$val = $_POST['inputText'];
$result= 0;
if(strstr($val,'+'))
	{	
		$n = explode('+',$val);
		$result = $n[0]+$n[1];
	
	}
else if(strstr($val,'-'))
	{	
		$n = explode('-',$val);
		$result =$n[0]-$n[1] ;
	}
else if(strstr($val,'*'))
	{
		$n = explode('*',$val);
		$result = $n[0] * $n[1];
	}
else if(strstr($val,'/'))
	{
		$n = explode('/',$val);
		if($n[1]==0)
		{
			//echo "division not possible";
		}
		else
		{
		    $result=$n[0]/$n[1];
	        //echo $result;
		}
	}
	else if(strpos($val,'si'))
	{
		$n = explode('asin',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = asin($result1);
		}
	}
	else if(strpos($val,'co'))
	{
		$n = explode('acos',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = acos($result1);
		}
	}
	else if(strpos($val,'an'))
	{
		$n = explode('atan',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = atan($result1);
		}
	}

else if(strpos($val,'in'))
	{
		$n = explode('sin',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = sin($result1);
		}
	}
else if(strpos($val,'os'))
	{
		$n = explode('cos',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = cos($result1);
		}

	}
else if(strpos($val,'an'))
	{
		$n = explode('tan',$val);
		if(isset($n[1]))
		{
			$result1 = deg2rad($n[1]);
			$result = tan($result1);
		}
	}
else if(strstr($val,'%'))
	{
		$result = $val/100;

	}
else if(strpos($val,'q'))
	{
		$n = explode('sqrt',$val);
		if(is_numeric($n[0]))
				{
					$result=sqrt($n[0]);					
				}
				else if(is_numeric($n[1]))
				{
					$result=sqrt($n[1]);
				}	
	}

			else if(strpos($val,'^'))
				{
					$n = explode('^',$val);
					$result = pow($n[0],$n[1]);
				}
			else if(strpos($val,'o'))
				{
					$n = explode('log',$val);
					if(is_numeric($n[0]))
					{
					$result = log10($n[0]);
					}
					else if(is_numeric($n[1]))
					{
					$result = log10($n[1]);
					}
				
				
				}
			else if(strpos($val,'n'))
				{
					$n = explode('ln',$val);
					if(is_numeric($n[0]))
					{
					$result = log($n[0]);
					}
				else if(is_numeric($n[1]))
					{
					$result = log($n[1]);
					}
				}
			else if(strpos($val,'x'))
				{
					$n = explode('x',$val);
					$result = $n[0] * $n[0];
					
				}
		

	else if(strstr($val, '!')==true)
	{
     list($n1)=explode("!", $val);
	 if($n1<=1)
		{
		 $result = 1;
		}
	else
		{
			$k=1;
			for($i=$n1;$i>=1;$i--)
			{   
				$k=$k*$i;
			}
			$result=$k ;
		}
	}
	
}



if(isset($_POST['Round']))
{
$val = $_POST['inputText'];
$n = explode(',',$val);

$result = round($n[0],$n[1]);

}

if(isset($_POST['inv']))
{
$n = $_POST['inputText'];
$result = 1 / $n;

}
if(isset($_POST['floor']))
{
$n = $_POST['inputText'];
$result = floor($n);
}
if(isset($_POST['ceil']))
{
$n = $_POST['inputText'];
$result = ceil($n);
}

if(isset($_POST['dec2bin']))
{
$val = $_POST['inputText'];
$result = decbin($val);
}

if(isset($_POST['bindec']))
{
$val= $_POST['inputText'];
$result = bindec($val);
}

if(isset($_POST['hexdec']))
{
$val= $_POST['inputText'];
$result = hexdec($val);

}
if(isset($_POST['dechex']))
{
$val= $_POST['inputText'];
$result = dechex($val);

}
if(isset($_POST['decoct']))
{
$val= $_POST['inputText'];
$result = decoct($val);

}
if(isset($_POST['octdec']))
{
$val= $_POST['inputText'];
$result = octdec($val);

} 
?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
 <head>
  <title> new document </title>

<!--   <script type="text/javascript" language="javascript" src="js/jquery.validationEngine.js"> </script>
  <script type="text/javascript" language="javascript" src="js/jquery.validationEngine-en.js"> </script>
 -->
  <meta name="generator" content="editplus">
  <meta name="author" content="">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <link rel="stylesheet" type="text/css" media="all" href="css2/suvo.css">
   <link rel="stylesheet" type="text/css" media="all" href="css/validationEngine.jquery.css">
  <script type="text/javascript" language="javascript" src="js/jquery-1.4.2.min.js"> </script>
  <script type="text/javascript">
  $(document).ready(function() {
		$(".bgr").css("background-image","url('pi.png')");
	});
  function cal(value)
	 {	
		 document.getElementById("text").value = document.getElementById("text").value + value;
	 }
 
	 function chk(val)
	 {
	
				 document.getElementById("text").value = document.getElementById("text").value + val;
			
	 }
  function delt()
  {
	 
	var len=document.getElementById("text").value.length;
	if(document.getElementById("text").value!=null)
		  {
			document.getElementById("text").value = document.getElementById("text").value.substr(0,(len-1));
		  }
  
  }
  function alldelt()
  {
		
		if(document.getElementById("text").value!= null)
		{
			document.getElementById("text").value = null;		
		}
  
  }
  function chngcolor(obj)
  {
  
	obj.style.background="#FF33CC";
  
  }
  function chngcolor1(obj)
  {
  
	obj.style.background="pink";

  }
   function chngcolor2(obj)
  {
  
	obj.style.background="#00FFFF";
  
  }
  function chngcolor3(obj)
  {
  
	obj.style.background="#66FFFF";

  }
   function chngcol(obj)
  {
  
	obj.style.background="#FFFF00";
  
  }
  function chngcolr(obj)
  {
  
	obj.style.background="#FFFF99";

  }
   function chng(obj)
  {
  
	obj.style.background="#999900";
  
  }
  function chnge(obj)
  {
  
	obj.style.background="#99CC66";

  }
/* function show()
  {
	if(document.getElementById("div").style.display=="none")
	 {
		document.getElementById("div").style.display="block";
		document.getElementById("OPEN").value="CLOSE";
	 }
	else if(document.getElementById("div").style.display=="block" || document.getElementById("box1").style.display=="block" || document.getElementById("box2").style.display=="block" )
	 {
		document.getElementById("div").style.display="none";
		document.getElementById("box1").style.display="none";
		document.getElementById("box2").style.display="none";

		document.getElementById("OPEN").value="OPEN";
	 }
  }*/
function autobackground()
{

Element = document.getElementById("body");

//Element.style.backgroundColor = "#FF9966";
//Element.style.backgroundImage = ('win.jpg');
}
function bgcolor()
{
	Element = document.getElementById("body");
	Element.style.backgroundColor = document.css.bgColor.value;
}
 
  
  </script>
 </head>


 <body id="body" class="bgr">
 

  
  
  <FORM METHOD="GET" ACTION="#" id="css" name="css">
	<strong> <B><I><span class="text">BACKGROUND</span> </I></B> </strong>
	<INPUT TYPE="text" NAME="color" id="bgColor" value="#" style="width:80px;background:#FFFF66"/>
	<INPUT TYPE="button" VALUE="set" onclick="bgcolor()" style="background:#CCFF00;"/>
  </FORM>


<center> 
	<div style="width:300px;height:50px;background:#9933CC;border-radius:35px;border:5px inset yellow;font-size:25px;color:#00FFFF"><B>CALCULATOR DESIGN</B> </div>
</center>


 <!-- <center>
	 <blink>
		 <INPUT TYPE="button" VALUE="OPEN" id="OPEN"style="background:#00CCCC;border-radius:20px;height:50px;width:70px" ONCLICK="show()">
	 </blink>
 </center>
 -->
 
<form method="POST" action="" id="f1" name="f1">
<div class="outbox"id="box1">

		 	<div class="box1">
				<input type="submit" value="bin2dec"name="bindec"onclick="" style="color:#993300;background:#00FF00"class="left">
			</div>
			<div class="box1">
				<input type="submit" value="dec2bin"name="dec2bin"onclick="" style="color:#993300;background:#00FF00"class="left">
			</div>
			<div class="box1">
				<input type="submit" value="hex2dec"name="hexdec"onclick="" style="color:#993300;background:#00FF00"class="left">
			</div> 
</div>


 <div class="outbox2"id="box2">

			<div class="box1">
				<input type="submit" value="dec2hex"name="dechex"onclick="" style="color:#993300;background:#00FF00"class="right">
			</div>
			<div class="box1">
				<input type="submit" value="dec2oct"name="decoct"onclick="" style="color:#993300;background:#00FF00"class="right">
			</div>
			<div class="box1">
				<input type="submit" value="oct2dec"name="octdec"onclick="" style="color:#993300;background:#00FF00"class="right">
			</div>
</div> 


<center>
<!--    <div style="height:510px;width:810px;border-radius:55px;background-image:url('FILE23.ico');background-repeat:repeat">
 -->     <div align="center" style="" id="div">

     
					<div class="menu">

								  <div>
									<INPUT TYPE="text" NAME="inputText" class="textarea" readonly="on" id="text"  value="<?php if(isset($_POST['inputText'])) { echo $result; } ?>"/>
								  </div>

								  <div class="box">


											<div class="box1">
												<input type="button" value="7" name="7"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="8" name="8" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="9"name="9"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="/"name="/" id="div" onclick="chk(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div>
											<div class="box1">
												<input type="button" value="%" name="%"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div>
											<div class="box1">
												<input type="button" value="sin "name="sin" style="color:#993300;background:#CCFF00" onclick="cal(this.value)"class="button">
											</div>
											<div class="box1">
												<input type="button" value="cos "name="cos"onclick="cal(this.value)" style="color:#993300;background:#CCFF00"class="button">
											</div>
											<div class="box1">
												<input type="button" value="log "name="log"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div>

								</div>



								<div class="box">

											<div class="box1">
												<input type="button" value="4" name="4"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="5" name="5"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="6"name="6"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
											</div>
											<div class="box1">
												<input type="button" value="*" name="*" id="mul" onclick="chk(this.value);" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div>
											 <div class="box1">
												<input type="submit" value="inv" name="inv"onclick="" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div> 
											<div class="box1">
												<input type="button" value="tan "name="tan"onclick="cal(this.value)" style="color:#993300;background:#CCFF00"class="button">
											</div>
											<div class="box1">
												<input type="button" value="3.14"name="pi"onclick="cal(this.value)" style="" class="pi">
											</div>
											<div class="box1">
												<input type="button" value="ln "name="ln"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
											</div>

								</div>





								<div class="box">

										<div class="box1">
											<input type="button" value="1"name="1" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
										</div>
										<div class="box1">
											<input type="button" value="2" name="2"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
										</div>
										<div class="box1">
											<input type="button" value="3"name="3"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
										</div>
										<div class="box1">
											<input type="button" value="-" name="-" id="min" onclick=" chk(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
										</div>
										<div class="box1">
											<input type="button" value="+" name="+" id="plus"onclick=" chk(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
										</div>
										<div class="box2">
											<input type="button" value="A"name="A" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)" class="abcd">
											<input type="button" value="B"name="B" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd">
											<input type="button" value="C"name="C" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
											<input type="button" value="D"name="D" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
											<input type="button" value="E"name="E" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
											<input type="button" value="F"name="F" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
											<input type="button" value="X"name="X" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
											<input type="button" value="Y"name="Y" onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"class="abcd" >
										</div>
										
										<div class="box1">
											<input type="button" value="asin "name="asin"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="button">
										</div>

									
								</div>

								
								<div class="box">

												<div class="box1">
													<input type="button" value="0"name="0"onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
												</div>
												<div class="box1">
													<input type="button" value="." name="."onclick="cal(this.value)" onmouseover="chng(this)" onmouseout="chnge(this)"  class="button1">
												</div>
												<div class="box1">
													<input type="submit" value="" name="equal" onclick=""  class="equal">
												</div>
												<div class="box1">
													<input type="button" value="CLEAR"name="back" onclick="delt()" onmouseover="chngcol(this)" onmouseout="chngcolr(this)"  class="cler">
												</div>
												<div class="box1">
													<input type="button" value="RESET" name="clear" onclick="alldelt();" onmouseover="chngcolor2(this)" onmouseout="chngcolor3(this)"  class="reset">
												</div>
												<div class="box1">
													<input type="button" value="x" name="sqr" onclick="cal(this.value)"  class="xsquare">
												</div>
												<div class="box1">
													<input type="button" value=""name="op"onclick="$('#box1,#box2').slideToggle('slow')"  class="convertion">
												</div>
												
												<div class="box1">
													<input type="button" value="acos "name="acos"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)"  class="tan">
												</div>		

								</div>
							
								<div class="box">

										<div class="box1">
												<input type="button" value=","name=","onclick="cal(this.value)"style="color:#993300;background:#FFFF00"  class="button1">
										</div>
										<div class="box1">
												<input type="button" value="!"name="!"onclick="cal(this.value)" class="fact">
										</div>
										<div class="box1">
												<input type="button" value="sqrt "name="sqrt"onclick="cal(this.value)"  class="sqr">
										</div>
										<div class="box1">
											<input type="submit" value="ceil"name="ceil"onclick="" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)" class="button">
										</div>
										<div class="box1">
											<input type="submit" value="floor "name="floor"onclick="" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)" class="button">
										</div>
										<div class="box1">
											<input type="submit" value="round "name="Round"onclick="" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)" class="button"> 
										</div>
										<div class="box1">
											<input type="button" value="^"name="^"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)" class="button">
										</div>
										<div class="box1">
											<input type="button" value="atan  "name="atan"onclick="cal(this.value)" onmouseover="chngcolor(this)" onmouseout="chngcolor1(this)" class="button">
										</div>

							 </div>

				</div>
	
		 
	</div>
 
</center>
</form>
 </body>
</html>
