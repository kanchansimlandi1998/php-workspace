<?php
if(isset($_POST['equal']))
{

$a=$_POST['7'];
echo $a;

}



?>
















<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
 <head>
  <title> new document </title>
  <link rel="stylesheet" type="text/css" media="all" href="css2/suvo.css">
  <meta name="generator" content="editplus">
  <meta name="author" content="">
  <meta name="keywords" content="">
  <meta name="description" content="">
 </head>


 <body>
 <div align="center">
 <form method=post action="">
	
 
		<div class="menu">
			  <div>
				<textarea name="" rows="3" cols="56" style="resize:none"></textarea>
			  </div>
			  <div class="box">
				<div class="box1">
					<input type="button" value="7" name="7" id="7" onclick=" " class="button">
				</div>
				<div class="box1">
					<input type="button" value="8" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="9" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="/" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="%" onclick="" class="button">
				</div>
			</div>
			<div class="box">
				<div class="box1">
					<input type="button" value="4" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="5" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="6" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="*" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="1/x" onclick="" class="button">
				</div>
			</div>
			<div class="box">
				<div class="box1">
					<input type="button" value="1" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="2" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="3" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="-" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="back" onclick="" class="button">
				</div>
			</div>
			
			<div class="box2">
				<div class="box1">
					<input type="button" value="0" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="." onclick="" class="button">
				</div>
				<div class="box1">
					<input type="button" value="+" onclick="" class="button">
				</div>
				<div class="box1">
					<input type="submit" value="=" name="equal" onclick="" class="button">
				</div>
				
			</div>
			
		</div>
  </form>
  </div>
 </body>
</html>
